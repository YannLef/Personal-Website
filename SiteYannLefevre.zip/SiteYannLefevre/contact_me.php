<?php
// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_POST['contact'])){
       
  $name     = htmlentities($_POST['name']);
  $email   = htmlentities($_POST['email']);
  $phone   = htmlentities($_POST['phone']);
  $message = htmlentities($_POST['message']);
  
  $receiver = "yann.lefevre@isen.yncrea.fr";
  $subject = "Mail from your website.";
  $mail = "Here is the contact form that as submitted on your website : \n"
          . "Name : ".$name."\n"
          . "Email : ".$email."\n"
          . "Phone : ".$phone."\n"
          . "Message : ".$message."\n";
mail( $receiver , $subject , $mail );

header('Location: index.php');
}
?>
