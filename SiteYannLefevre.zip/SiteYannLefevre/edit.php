<?php
session_start();
if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) // Check if already connected
{
    ?>
    <!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Yann Lefevre's personal website. Here you can find many informations about me, my skills and many projects I've done.">
    <meta name="author" content="Yann Lefevre">

    <title>Yann LEFEVRE - Software Engineering Student</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Magnific Popup CSS -->
    <link href="magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.css" rel="stylesheet">
   

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
      <div class="container width1300">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Yann LEFEVRE</a>
        <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#about">About</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#skills">Skills</a>
            </li>            
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#experience">Work Experience</a>
            </li>            
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#portfolio">Portfolio</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#contact">Contact</a>
            </li>
            <?php
                if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) // Check if already connected
                {
            ?>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="edit.php">Edit</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="logout.php">Logout</a>
            </li>
            <?php
                }else{
            ?>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="portfolio-item nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#login-popup">Login</a>
            </li>
            <?php
                }
            ?>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <img class="img-fluid mb-5 d-block mx-auto" src="img/profile.png" alt="">
        <h1 class="text-uppercase mb-0">Yann LEFEVRE</h1>
        <hr class="star-light">
        <input type="text" value="yo"><h2 class="font-weight-light mb-0">Software Engineering Student</h2>
      </div>
    </header>

    <!-- About Section -->
    <section class="mb-0" id="about">
      <div class="container">
        <h2 class="text-center text-uppercase">About</h2>
        <hr class="star-dark mb-5">
        <div class="row">
          <div class="col-xs-4 text-center ml-auto">
            <p class="lead">Currently in the second year of the <a href="https://www.isen-mediterranee.fr/fr/content/cir_cpa32_dcc5.htm">Computer Sciences and Networks Cycle</a> at <a href="https://www.isen-mediterranee.fr/">ISEN Toulon</a>, my professional goal is to become an engineer in the software engineering sector. I am open to any proposal for internships or professional experience.</p>
    
            <p class="lead">If you are interested in my profile, you can download my resume using the button below :</p>
            <div class="text-center mt-4">
                <a class="btn btn-xl btn-outline-dark" href="files/LEFEVRE_YANN_Resume.pdf" download>
                <i class="fas fa-download mr-2"></i>
                Download Now!
              </a>
            </div>
            <br>
            <p class="lead">You can also find me on social networks :</p>  
            <ul class="list-inline mb-0">
              <li class="list-inline-item">
                <a class="btn btn-outline-dark btn-social text-center rounded-circle" target='_blank' href="https://www.linkedin.com/in/lefevre-yann/?locale=en_US">
                  <i class="fab fa-fw fa-linkedin-in"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-dark btn-social text-center rounded-circle" target='_blank' href="https://github.com/YannLef">
                  <i class="fab fa-fw fa-github"></i>
                </a>
              </li>              
            </ul>                
          </div>
        </div>
      </div>
    </section>
    
    <!-- Skills Section --> 
    <section class="bg-primary text-white mb-0" id="skills">
      <div class="container">
        <h2 class="text-center text-uppercase">Skills</h2>
        <hr class="star-light mb-5">
         <div class="p-lg-5 p-3">
          <h3 class="text-center text-white text-uppercase">Coding Skills</h3>
          <div class="row text-center my-auto"> 
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fab fa-cuttlefish fa-5x"></i>
                      <h2><span class="counter">81</span><span> %</span></h2>
                      <p>C Language</p>
                  </div>
              </div>
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fab fa-java fa-5x"></i>
                      <h2><span class="counter">60</span><span> %</span></h2>
                      <p>Processing</p>
                  </div>
              </div>
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fab fa-php fa-5x"></i>
                      <h2><span class="counter">65</span><span> %</span></h2>
                      <p>Php</p>
                  </div>
              </div>
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fab fa-js-square fa-5x"></i>
                      <h2><span class="counter">40</span><span> %</span></h2>
                      <p>Javascript</p>
                  </div>
              </div>
          </div>          
          <div class="row text-center my-auto"> 
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fas fa-database fa-5x"></i>
                      <h2><span class="counter">68</span><span> %</span></h2>
                      <p>SQL</p>
                  </div>
              </div>              
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fab fa-html5 fa-5x"></i>
                      <h2><span class="counter">84</span><span> %</span></h2>
                      <p>HTML5</p>
                  </div>
              </div>
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fab fa-css3-alt fa-5x"></i>
                      <h2><span class="counter">82</span><span> %</span></h2>
                      <p>CSS3</p>
                  </div>
              </div>
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="fab fa-linux fa-5x"></i>
                      <h2><span class="counter">55</span><span> %</span></h2>
                      <p>Linux</p>
                  </div>
              </div>
          </div>
         </div> 
      </div>
    </section>
    
    <!-- Work Experience Section -->
    <section class="mb-0" id="experience">
      <div class="container">
        <h2 class="text-center text-uppercase">Work Experience</h2>
        <hr class="star-dark mb-5">
        
        <div class="row my-auto">
            
            
              <div class="resume-item col-md-6 col-sm-12 " > 
                <div class="card mx-0 p-4 mb-5 experience-box">
                  <div class=" resume-content mr-auto">
                      <h4 class="mb-3"><i class="fas fa-comment-dots mr-3 text-primary"></i> Head of Communications at Junior Isen-Toulon : <i class="fas fa-eye" id="experience-show-6" style="display: inline; cursor: pointer;" onclick="show_experience(6)"></i><i class="fas fa-eye-slash" id="experience-hide-6" style="display: none; cursor: pointer;" onclick="show_experience(6)"></i></h4>
                      
                      <p id="experience-text-6" style="display: none;">In charge of the communication team of Junior Isen-Toulon : team management, posters creation, social networks administration, events management...<br>
                      Development of my leadership, my team spirit and my knowledges about communication tools.</p>
                  </div>
                  <div class="resume-date text-md-right">
                      <span class="text-primary">May 2018 - Today</span>
                  </div>
                </div>  
              </div>
              <div class="resume-item col-md-6 col-sm-12 " > 
                <div class="card mx-0 p-4 mb-5 experience-box">
                  <div class=" resume-content mr-auto">
                      <h4 class="mb-3"><i class="fas fa-tree mr-3 text-primary"></i> Summer Job: Gardener and Housekeeper : <i class="fas fa-eye" id="experience-show-5" style="display: inline; cursor: pointer;" onclick="show_experience(5)"></i><i class="fas fa-eye-slash" id="experience-hide-5" style="display: none; cursor: pointer;" onclick="show_experience(5)"></i></h4>
                      <p id="experience-text-5" style="display: none;">In charge of the maintenance of gardens for private individuals.<br>
                      Development of my rigor, my punctuality and my sense of responsibility.</p>
                  </div>
                  <div class="resume-date text-md-right">
                      <span class="text-primary">July 2018 - August 2018</span>
                  </div>
                </div>  
              </div>
              <div class="resume-item col-md-6 col-sm-12">
                <div class="card mx-0 p-4 mb-5 experience-box">
                  <div class="resume-content mr-auto">
                      <h4 class="mb-3"><i class="fab fa-free-code-camp mr-3 text-primary"></i> Associative Internship: Forest Fire Protection : <i class="fas fa-eye" id="experience-show-4" style="display: inline; cursor: pointer;" onclick="show_experience(4)"></i><i class="fas fa-eye-slash" id="experience-hide-4" style="display: none; cursor: pointer;" onclick="show_experience(4)"></i></h4>
                      <p id="experience-text-4" style="display: none;">Member of a team working on fires and prevention actions.<br>
                      Development of my team spirit and my risk management.</p>
                  </div>
                  <div class="resume-date text-md-right">
                      <span class="text-primary">June 2018 - July 2019</span>
                  </div>
                </div>  
              </div>
                
              <div class="resume-item col-md-6 col-sm-12">
                <div class="card mx-0 p-4 mb-5 experience-box">
                  <div class="resume-content mr-auto">
                      <h4 class="mb-3"><i class="fas fa-comment-dots mr-3 text-primary"></i> Communication Officer at Junior Isen-Toulon : <i class="fas fa-eye" id="experience-show-3" style="display: inline; cursor: pointer;" onclick="show_experience(3)"></i><i class="fas fa-eye-slash" id="experience-hide-3" style="display: none; cursor: pointer;" onclick="show_experience(3)"></i></h4>
                      <p id="experience-text-3" style="display: none;">Member of the communication team of Junior Isen-Toulon : posters creation, social networks administration, events management...<br>
                      Development of my team spirit and my knowledges about communication tools.</p>
                  </div>
                  <div class="resume-date text-md-right">
                      <span class="text-primary">September 2017 - May 2018</span>
                  </div>
                </div>  
              </div>
              <div class="resume-item col-md-6 col-sm-12 " > 
                <div class="card mx-0 p-4 mb-5 experience-box">
                  <div class=" resume-content mr-auto">
                      <h4 class="mb-3"><i class="fas fa-tree mr-3 text-primary"></i> Summer Job: Gardener and Housekeeper : <i class="fas fa-eye" id="experience-show-2" style="display: inline; cursor: pointer;" onclick="show_experience(2)"></i><i class="fas fa-eye-slash" id="experience-hide-2" style="display: none; cursor: pointer;" onclick="show_experience(2)"></i></h4>
                      <p id="experience-text-2" style="display: none;">In charge of the maintenance of gardens for private individuals.<br>
                      Development of my rigor, my punctuality and my sense of responsibility.</p>
                  </div>
                  <div class="resume-date text-md-right">
                      <span class="text-primary">June 2017 - July 2017</span>
                  </div>
                </div>  
              </div>
              <div class="resume-item col-md-6 col-sm-12">
                <div class="card mx-0 p-4 mb-5 experience-box">
                  <div class="resume-content mr-auto">
                      <h4 class="mb-3"><i class="fas fa-glass-martini-alt mr-3 text-primary"></i> Summer Job: Restaurant Waiter at La Figuière : <i class="fas fa-eye" id="experience-show-1" style="display: inline; cursor: pointer;" onclick="show_experience(1)"></i><i class="fas fa-eye-slash" id="experience-hide-1" style="display: none; cursor: pointer;" onclick="show_experience(1)"></i></h4>
                      <p id="experience-text-1" style="display: none;">Responsible for the care of customers: reception, order taking, service...<br>
                      Development of my human relations.</p>
                  </div>
                  <div class="resume-date text-md-right">
                      <span class="text-primary">June 2013 - July 2013</span>
                  </div>
                </div>  
              </div>
            
          </div>
      </div>
    </section>    
    
    <!-- Portfolio Grid Section -->
    <section class="bg-primary text-white portfolio" id="portfolio">
      <div class="container">
        <h2 class="text-center text-uppercase">Portfolio</h2>
        <hr class="star-light mb-5">
        <div class="row">
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto" href="#portfolio-modal-1">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/personal-website.png" alt="">
            </a>
          </div>
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto" href="#portfolio-modal-2">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/database-manager.png" alt="">
            </a>
          </div>
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto" href="#portfolio-modal-3">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/crossfit-drakon.png" alt="">
            </a>
          </div>
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto" href="#portfolio-modal-4">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/square-arena.png" alt="">
            </a>
          </div>
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto" href="#portfolio-modal-5">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/mathematical_beauty.png" alt="">
            </a>
          </div>
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto" href="#portfolio-modal-6">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/retro_pinball.png" alt="">
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- Contact Section -->
    <section id="contact">
      <div class="container">
        <h2 class="text-center text-uppercase text-secondary mb-0">Contact Me</h2>
        <hr class="star-dark mb-5">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
            <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
            <form name="sentMessage" id="contactForm" novalidate="novalidate">
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Name</label>
                  <input class="form-control" id="name" type="text" placeholder="Name" required="required" data-validation-required-message="Please enter your name.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Email Address</label>
                  <input class="form-control" id="email" type="email" placeholder="Email Address" required="required" data-validation-required-message="Please enter your email address.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Phone Number</label>
                  <input class="form-control" id="phone" type="tel" placeholder="Phone Number" required="required" data-validation-required-message="Please enter your phone number.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Message</label>
                  <textarea class="form-control" id="message" rows="5" placeholder="Message" required="required" data-validation-required-message="Please enter a message."></textarea>
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <br>
              <div id="success"></div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-xl" id="sendMessageButton">Send</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">Toulon, France</p>
          </div>
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Around the Web</h4>
            <ul class="list-inline mb-0">
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" target='_blank' href="https://www.linkedin.com/in/lefevre-yann/?locale=en_US">
                  <i class="fab fa-fw fa-linkedin-in"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" target='_blank' href="https://github.com/YannLef">
                  <i class="fab fa-fw fa-github"></i>
                </a>
              </li>              
            </ul>
          </div>
          <div class="col-md-4">
            <h4 class="text-uppercase mb-4">About Me</h4>
            <p class="lead mb-0">I am open to any proposal for internships or professional experience</p>
          </div>
        </div>
      </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
      <div class="container">
        <small>Copyright &copy; Yann Lefevre 2018</small>
      </div>
    </div>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Portfolio Modals -->

    <!-- Portfolio Modal 1 -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-1">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Personal Website</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/personal-website.png" alt="">
              <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Portfolio Modal 2 -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-2">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Database Manager</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/database-manager.png" alt="">
              <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Portfolio Modal 3 -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-3">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Crossfit Drakon</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/crossfit-drakon.png" alt="">
              <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Portfolio Modal 4 -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-4">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Square Arena</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/square-arena.png" alt="">
              <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Portfolio Modal 5 -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-5">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Mathematical Beauty</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/mathematical_beauty.png" alt="">
              <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Portfolio Modal 6 -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-6">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Retro Pinball</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/retro_pinball.png" alt="">
              <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Login Popup -->
    <div class="portfolio-modal mfp-hide" id="login-popup">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Log In</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/profile" alt="">
              <p></p>
              <form method="post" id="login-form" autocomplete="off">
                <div class="form-group">
                    <input type="email" name="email" id="mail" class="form-control" placeholder="Mail">
                </div>
                <div class="form-group">
                    <input type="password" name="password" id="key" class="form-control" placeholder="Password">
                </div>
                <div class="checkbox">
                    <input class='switch' id='showkey' type='checkbox' onclick="showPassword()">
                    <label for='showkey' class="label">Show password</label>
                </div>
                <input type="submit" id="btn-login" name='btn-login' class="btn btn-primary btn-xl" value="Log in">
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- JQuery and Bootstrap js -->
    <script src="js/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    
    <!-- Counter from Skills Section -->
    <!-- Requires JQuery but already imported -->
    <script src="js/counter/jquery.waypoints.min.js" type="text/javascript"></script>
    <script src="js/counter/jquery.counterup.min.js" type="text/javascript"></script>
    <script>
        jQuery(document).ready(function($) {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        });
    </script>
    
    <!-- Jquery Easing -->
    <script src="jquery-easing/jquery.easing.min.js"></script>
    
    <!-- Jquery Magnific Popup -->
    <script src="magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    
    <!-- Click to show script from Work Experience Section -->
    <script src="js/experience/experience.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/freelancer.js"></script>    

  </body>

</html>
<?php
}

?>

