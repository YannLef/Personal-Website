<?php

// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_POST['add_skill']) && isset($_POST['name']) && isset($_POST['number']) && isset($_POST['icon'])){
       $name = addslashes($_POST['name']);
       $number = addslashes($_POST['number']);
       $icon = addslashes($_POST['icon']);
       
       
       $db->exec("INSERT INTO skills (name, number, icon) VALUES ('$name', '$number', '$icon')");
       header('Location: index.php');
   }

?>