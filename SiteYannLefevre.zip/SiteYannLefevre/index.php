<?php
session_start();
				try {
					$db = new PDO('mysql:host=localhost; dbname=siteweb', 'root', '');
				  }
				  catch(exception $e) {
					die('Erreur '.$e->getMessage());
				  }
    include 'uploadCV.php';
    include 'addskill.php';
    include 'removeskill.php';
    include 'updateskill.php';
    include 'addwork.php';
    include 'removework.php';
    include 'updatework.php';
    include 'contact_me.php';
    include 'addproject.php';
    include 'removeproject.php';
    include 'updateproject.php';

?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Yann Lefevre's personal website. Here you can find many informations about me, my skills and many projects I've done.">
    <meta name="author" content="Yann Lefevre">
    
    <?php
        $stmt = $db->query("SELECT text FROM content WHERE id='intro_title'");
	$user = $stmt->fetch();
    ?>

    <title><?php echo "Yann LEFEVRE - ".$user['text']; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Magnific Popup CSS -->
    <link href="magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.css" rel="stylesheet">
   

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
      <div class="container width1300">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Yann LEFEVRE</a>
        <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#about">About</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#skills">Skills</a>
            </li>            
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#experience">Work Experience</a>
            </li>            
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#portfolio">Portfolio</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#contact">Contact</a>
            </li>
            <?php
                if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) // Check if already connected
                {
            ?>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="logout.php">Logout</a>
            </li>
            <?php
                }else{
            ?>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="portfolio-item nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#login-popup">Login</a>
            </li>
            <?php
                }
            ?>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <img class="img-fluid mb-5 d-block mx-auto" src="img/profile.png" alt="">
        <h1 class="text-uppercase mb-0">Yann LEFEVRE</h1>
        <hr class="star-light">
                    <?php
                if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) // Check if already connected
                {
            ?>
        <form method="post" action="update.php?id=intro_title"><input id="intro_title" type="text" name="text"><input type="submit" value="update"></form>
        <?php
                }
        ?>
        <h2 class="font-weight-light mb-0"><?php echo $user['text']; ?></h2>
      </div>
    </header>

    <!-- About Section -->
    <section class="mb-0" id="about">
      <div class="container">
        <h2 class="text-center text-uppercase">About</h2>
        <hr class="star-dark mb-5">
        <div class="row">
          <div class="col-xs-4 text-center m-auto w100">
                    <?php
        $stmt = $db->query("SELECT text FROM content WHERE id='about_text'");
	$user = $stmt->fetch();
                if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) // Check if already connected
                {
                   
            ?>
        <form method="post" action="update.php?id=about_text"><input id="about_text" type="text" name="text" ><input type="submit" value="update"></form>
        <?php
                }
        ?>
            <p class="lead"><?php echo $user['text']; ?></p>
            <?php
                            if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) // Check if already connected
                {
                   
            ?>
        <form action="" method="post" enctype="multipart/form-data"><input type="file" name="cv"><input type="submit" value="upload"></form>
        <?php
                }
        ?>
            <div class="text-center mt-4">
                <a class="btn btn-xl btn-outline-dark" href="files/LEFEVRE_YANN_Resume.pdf" download>
                <i class="fas fa-download mr-2"></i>
                Download Now!
              </a>
            </div>
            <br>
            <p class="lead">You can also find me on social networks :</p>  
            <ul class="list-inline mb-0">
              <li class="list-inline-item">
                <a class="btn btn-outline-dark btn-social text-center rounded-circle" target='_blank' href="https://www.linkedin.com/in/lefevre-yann/?locale=en_US">
                  <i class="fab fa-fw fa-linkedin-in"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-dark btn-social text-center rounded-circle" target='_blank' href="https://github.com/YannLef">
                  <i class="fab fa-fw fa-github"></i>
                </a>
              </li>              
            </ul>                
          </div>
        </div>
      </div>
    </section>
    
    <!-- Skills Section --> 
    <section class="bg-primary text-white mb-0" id="skills">
      <div class="container">
        <h2 class="text-center text-uppercase">Skills</h2>
        <hr class="star-light mb-5">
         <div class="p-lg-5 p-3">
          <h3 class="text-center text-white text-uppercase">Coding Skills</h3>
          <?php
          if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) { // Check if already connected
              ?>
              <form method="post" action="" class="text-center">
                  <input name="name" type="text" class="input_add_skill" placeholder="Name"><br>
                  <input name="number" type="text" class="input_add_skill" placeholder="Number"><br>
                  <input name="icon" type="text" class="input_add_skill" placeholder="Icon"><br>
                  <input name="add_skill" type="submit" value="add skill" class="input_add_skill">
              </form>
              <br>
              <form method="post" action="" class="text-center">
                  <input name="id" type="text" class="input_add_skill" placeholder="id"><br>
                  <input name="remove_skill" type="submit" value="remove skill" class="input_add_skill">
              </form>
              <br>
              <form method="post" action="" class="text-center">
                  <input name="id" type="text" class="input_add_skill" placeholder="Id"><br>
                  <input name="name" type="text" class="input_add_skill" placeholder="Name"><br>
                  <input name="number" type="text" class="input_add_skill" placeholder="Number"><br>
                  <input name="icon" type="text" class="input_add_skill" placeholder="Icon"><br>
                  <input name="update_skill" type="submit" value="update skill" class="input_add_skill">
              </form>              

    <?php
}
?>
          <div class="row text-center my-auto">
              <?php
        $stmt = $db->query("SELECT * FROM skills ORDER BY number DESC");
        
        foreach ($stmt as $row) {              
              ?>
              
              <div class="col-md-3 col-sm-6">
                  <div class="skill-item">
                      <i class="<?php echo $row['icon']; ?> fa-5x"></i>
                      <h2><span class="counter"><?php echo $row['number'] ?></span><span> %</span></h2>
                      <p><?php echo $row['name'] ?><?php if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])){ echo " (id : ".$row['id'].") "; }?></p>
                  </div>
              </div>
              
              <?php
        }
        ?>
          </div>
         </div> 
      </div>
    </section>
    
    <!-- Work Experience Section -->
    <section class="mb-0" id="experience">
      <div class="container">
        <h2 class="text-center text-uppercase">Work Experience</h2>
        <hr class="star-dark mb-5">
        
                                    <?php
                            if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) // Check if already connected
                {
                   
            ?>
                      <form method="post" action="" class="text-center">
                          <input name="title" type="text" class="input_add_skill" placeholder="Title"><br>
                          <input name="text" type="text" class="input_add_skill" placeholder="Text"><br>
                          <input name="icon" type="text" class="input_add_skill" placeholder="Icon"><br>
                          <input name="date" type="text" class="input_add_skill" placeholder="Date"><br>
                          <input name="add_work" type="submit" value="add work" class="input_add_skill">
                      </form>
          <br>
                       <form method="post" action="" class="text-center">
                          <input name="id" type="text" class="input_add_skill" placeholder="id"><br>
                          <input name="remove_work" type="submit" value="remove work" class="input_add_skill">
                      </form>
          <br>
                      <form method="post" action="" class="text-center">
                          <input name="id" type="text" class="input_add_skill" placeholder="Id"><br>
                          <input name="title" type="text" class="input_add_skill" placeholder="Title"><br>
                          <input name="text" type="text" class="input_add_skill" placeholder="Text"><br>
                          <input name="icon" type="text" class="input_add_skill" placeholder="Icon"><br>
                          <input name="date" type="text" class="input_add_skill" placeholder="Date"><br>
                          <input name="update_work" type="submit" value="update work" class="input_add_skill">
                      </form>
              
              <?php
                }

              ?>
        
        <div class="row my-auto">
            
                                  <?php
        $stmt = $db->query("SELECT * FROM work ORDER BY id DESC");
        
        foreach ($stmt as $row) {              
              ?>
                    
              <div class="resume-item col-md-6 col-sm-12">
                <div class="card mx-0 p-4 mb-5 experience-box">
                  <div class="resume-content mr-auto">
                      <h4 class="mb-3"><i class="<?php echo $row['icon'] ?> mr-3 text-primary"></i><?php echo $row['title'] ?> <?php if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])){ echo " (id : ".$row['id'].") "; }?> <i class="fas fa-eye" id="experience-show-<?php echo $row['id'] ?>" style="display: inline; cursor: pointer;" onclick="show_experience(<?php echo $row['id'] ?>)"></i><i class="fas fa-eye-slash" id="experience-hide-<?php echo $row['id'] ?>" style="display: none; cursor: pointer;" onclick="show_experience(<?php echo $row['id'] ?>)"></i></h4>
                      <p id="experience-text-<?php echo $row['id'] ?>" style="display: none;"><?php echo $row['text'] ?></p>
                  </div>
                  <div class="resume-date text-md-right">
                      <span class="text-primary"><?php echo $row['date'] ?></span>
                  </div>
                </div>  
              </div>
                    
                    <?php
        }
                    ?>
            
          </div>
      </div>
    </section>    
    
    <!-- Portfolio Grid Section -->
    <section class="bg-primary text-white portfolio" id="portfolio">
      <div class="container">
        <h2 class="text-center text-uppercase">Portfolio</h2>
        <hr class="star-light mb-5">
<?php
          if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) { // Check if already connected
              ?>
              <form method="post" action="" class="text-center" enctype="multipart/form-data">
                  <input name="title" type="text" class="input_add_skill" placeholder="Title"><br>
                  <input name="text" type="text" class="input_add_skill" placeholder="Text"><br>
                  <input type="file" name="picture"><br>
                  <input name="add_project" type="submit" value="add project" class="input_add_skill">
              </form>
              <br>
              <form method="post" action="" class="text-center">
                  <input name="id" type="text" class="input_add_skill" placeholder="id"><br>
                  <input name="remove_project" type="submit" value="remove project" class="input_add_skill">
              </form>
              <br>
              <form method="post" action="" class="text-center" enctype="multipart/form-data">
                  <input name="id" type="text" class="input_add_skill" placeholder="Id"><br>
                  <input name="title" type="text" class="input_add_skill" placeholder="Title"><br>
                  <input name="text" type="text" class="input_add_skill" placeholder="Text"><br>
                  <input type="file" name="picture"><br>
                  <input name="update_project" type="submit" value="update project" class="input_add_skill">
              </form>

    <?php
}
?>
        <div class="row">
            
            <?php
            $stmt = $db->query("SELECT * FROM portfolio ORDER BY id DESC");

            foreach ($stmt as $row) {
                ?>
            
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto text-center" href="#portfolio-modal-<?php echo $row['id']; ?>">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/<?php echo $row['id']; ?>" alt="">
              <?php
          if (isset($_SESSION['id_admin']) && isset($_SESSION['email']) && isset($_SESSION['password'])) { // Check if already connected
              
              echo '<p style="color: black;">(id : '.$row['id'].')</p>';
          }
              ?>
            </a>
          </div>
            
            <?php 
            }
            ?>
        </div>
      </div>
    </section>

    <!-- Contact Section -->
    <section id="contact">
      <div class="container">
        <h2 class="text-center text-uppercase text-secondary mb-0">Contact Me</h2>
        <hr class="star-dark mb-5">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
            <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
            <form name='contact_form' method='POST' action=''>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Name</label>
                  <input id="name" name='name' type="text" placeholder="Name" required="required" onchange='validateForm("name")'>
                  <p class="help-block text-danger" id='erreur_name'>Please enter your name.</p>
                </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Email Address</label>
                  <input id="email" name='email' type="email" placeholder="Email Address" required="required" onchange='validateForm("email")'>
                  <p class="help-block text-danger" id='erreur_email'>Please enter a valid e-mail address.</p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Phone Number</label>
                  <input name='phone' id="phone" type="tel" placeholder="Phone Number" required="required" onchange='validateForm("phone")'>
                  <p class="help-block text-danger" id='erreur_phone'>Please enter your telephone number.</p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Message</label>
                  <textarea id="message" name='message' rows="5" placeholder="Message" required="required" onchange='validateForm("message")'></textarea>
                  <p class="help-block text-danger" id='erreur_message'>Please enter your message.</p>
                </div>
              </div>
              <br>
              <div id="success"></div>
              <div class="form-group" id='send_contact' style='display: none;'>
                <input type="submit" class="btn btn-primary btn-xl" value='Send' name='contact'>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Location</h4>
            <p class="lead mb-0">Toulon, France</p>
          </div>
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4">Around the Web</h4>
            <ul class="list-inline mb-0">
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" target='_blank' href="https://www.linkedin.com/in/lefevre-yann/?locale=en_US">
                  <i class="fab fa-fw fa-linkedin-in"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-outline-light btn-social text-center rounded-circle" target='_blank' href="https://github.com/YannLef">
                  <i class="fab fa-fw fa-github"></i>
                </a>
              </li>              
            </ul>
          </div>
          <div class="col-md-4">
            <h4 class="text-uppercase mb-4">About Me</h4>
            <p class="lead mb-0">I am open to any proposal for internships or professional experience</p>
          </div>
        </div>
      </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
      <div class="container">
        <small>Copyright &copy; Yann Lefevre <?php echo date("Y"); ?></small>
      </div>
    </div>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Portfolio Modals -->
    
    <?php
    $stmt = $db->query("SELECT * FROM portfolio ORDER BY id ASC");

    foreach ($stmt as $row) {
        ?>

    <!-- Portfolio Modal <?php echo $row['id']; ?> -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-<?php echo $row['id']; ?>">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0"><?php echo $row['title']; ?></h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/<?php echo $row['id']; ?>.png" alt="">
              <p class="mb-5"><?php echo $row['text']; ?></p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div>

        <?php
    }
    ?>
    
    <!-- Login Popup -->
    <div class="portfolio-modal mfp-hide" id="login-popup">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Log In</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/profile" alt="">
              <form name='login-form' method="post" id="login-form">
                  <p class="help-block text-danger" id='erreur_general_login'></p>
                <div class="form-group">
                    <input type="email" name="email" id="mail" class="form-control" placeholder="Mail" onchange="validateLogin('email');">
                    <p class="help-block text-danger" id='erreur_email_login'>Please enter a valid email.</p>
                </div>
                <div class="form-group">
                    <input type="password" name="password" id="key" class="form-control" placeholder="Password" onchange="validateLogin('password');">
                    <p class="help-block text-danger" id='erreur_password_login'>Please enter your password.</p>
                </div>
                <div class="checkbox">
                    <input class='switch' id='showkey' type='checkbox' onclick="showPassword()">
                    <label for='showkey' class="label">Show password</label>
                </div>
                  <input type="button" onclick="login()" id="btn-login" name='btn-login' class="btn btn-primary btn-xl" value="Log in" style='display:none;'>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- JQuery and Bootstrap js -->
    <script src="js/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    
    <!-- Counter from Skills Section -->
    <!-- Requires JQuery but already imported -->
    <script src="js/counter/jquery.waypoints.min.js" type="text/javascript"></script>
    <script src="js/counter/jquery.counterup.min.js" type="text/javascript"></script>
    <script>
        jQuery(document).ready(function($) {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        });
    </script>
    
    <!-- Jquery Easing -->
    <script src="jquery-easing/jquery.easing.min.js"></script>
    
    <!-- Jquery Magnific Popup -->
    <script src="magnific-popup/jquery.magnific-popup.min.js"></script>
    
    <!-- Click to show script from Work Experience Section -->
    <script src="js/experience/experience.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/xml.js" type="text/javascript"></script>
    <script src="js/freelancer.js"></script>  

  </body>

</html>
