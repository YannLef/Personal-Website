<?php

// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_POST['add_project']) && isset($_POST['title']) && isset($_POST['text']) && isset($_FILES['picture'])){
       $title = addslashes($_POST['title']);
       $text = addslashes($_POST['text']);
       
       
      $errors= array();
      $file_name = $_FILES['picture']['name'];
      $file_size = $_FILES['picture']['size'];
      $file_tmp = $_FILES['picture']['tmp_name'];
      $file_type = $_FILES['picture']['type'];
      $explode = explode('.',$_FILES['picture']['name']);
      $file_ext=strtolower(end($explode));
      
      $expensions= array("png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a png.";
      }
      
      if($file_size > 2097152) {
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true) {
       $db->exec("INSERT INTO portfolio (title, text) VALUES ('$title', '$text')");
          
          $stmt = $db->query("SELECT MAX(id) FROM portfolio");
            $id = $stmt->fetchColumn();
          
          //$id = $user['id'] + 1;
         move_uploaded_file($file_tmp,"img/portfolio/".$id.".png");
          //move_uploaded_file($file_tmp,"img/test.png");
      }else{
         print_r($errors);
      }
       
       

       header('Location: index.php');
   }

?>