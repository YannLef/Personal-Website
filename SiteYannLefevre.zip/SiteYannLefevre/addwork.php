<?php

// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_POST['add_work']) && isset($_POST['title']) && isset($_POST['text']) && isset($_POST['icon']) && isset($_POST['date'])){
       $title = addslashes($_POST['title']);
       $text = addslashes($_POST['text']);
       $icon = addslashes($_POST['icon']);
       $date = addslashes($_POST['date']);
       
       
       $db->exec("INSERT INTO work (title, text, icon, date) VALUES ('$title', '$text', '$icon', '$date')");
       header('Location: index.php');
   }

?>