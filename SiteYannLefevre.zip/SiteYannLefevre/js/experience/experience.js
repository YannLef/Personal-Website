function show_experience(number){
    text = document.getElementById("experience-text-" + number);
    show = document.getElementById("experience-show-" + number);
    hide = document.getElementById("experience-hide-" + number);
    
    if(text.style.display === "none"){ // if user clicks on show
        text.style.display = "inline";
        show.style.display = "none";
        hide.style.display = "inline";
    }else{ // if user clicks on hide
        text.style.display = "none";
        show.style.display = "inline";
        hide.style.display = "none";
    }
        
        //.style.display = "block";
}