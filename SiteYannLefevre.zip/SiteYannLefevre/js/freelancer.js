(function($) {
  "use strict"; // Start of use strict

  // Smooth scrolling using jQuery easing
  $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: (target.offset().top - 70)
        }, 1000, "easeInOutExpo");
        return false;
      }
    }
  });

  // Scroll to top button appear
  $(document).scroll(function() {
    var scrollDistance = $(this).scrollTop();
    if (scrollDistance > 100) {
      $('.scroll-to-top').fadeIn();
    } else {
      $('.scroll-to-top').fadeOut();
    }
  });

  // Closes responsive menu when a scroll trigger link is clicked
  $('.js-scroll-trigger').click(function() {
    $('.navbar-collapse').collapse('hide');
  });

  // Activate scrollspy to add active class to navbar items on scroll
  $('body').scrollspy({
    target: '#mainNav',
    offset: 80
  });

  // Collapse Navbar
  var navbarCollapse = function() {
    if ($("#mainNav").offset().top > 100) {
      $("#mainNav").addClass("navbar-shrink");
    } else {
      $("#mainNav").removeClass("navbar-shrink");
    }
  };
  // Collapse now if page is not at top
  navbarCollapse();
  // Collapse the navbar when page is scrolled
  $(window).scroll(navbarCollapse);

  // Modal popup$(function () {
  $('.portfolio-item').magnificPopup({
    type: 'inline',
    preloader: false,
    focus: '#username',
    modal: true
  });
  $(document).on('click', '.portfolio-modal-dismiss', function(e) {
    e.preventDefault();
    $.magnificPopup.close();
  });

  // Floating label headings for the contact form
  $(function() {
    $("body").on("input propertychange", ".floating-label-form-group", function(e) {
      $(this).toggleClass("floating-label-form-group-with-value", !!$(e.target).val());
    }).on("focus", ".floating-label-form-group", function() {
      $(this).addClass("floating-label-form-group-with-focus");
    }).on("blur", ".floating-label-form-group", function() {
      $(this).removeClass("floating-label-form-group-with-focus");
    });
  });

})(jQuery); // End of use strict

function showPassword() {
    
    var key_attr = $('#key').attr('type');
    
    if(key_attr != 'text') {
        
        $('#key').attr('type', 'text');
        
    } else {
        
        $('#key').attr('type', 'password');
        
    }
    
}

function validateForm(input) {
    var name = document.forms["contact_form"]["name"];               
    var email = document.forms["contact_form"]["email"];    
    var phone = document.forms["contact_form"]["phone"];
    var message = document.forms["contact_form"]["message"];
    
    if(input === "name"){
        var erreur = 0;
        if (name.value === "")                                  
        { 
            document.getElementById("erreur_name").innerHTML = "Please enter your name.";
            erreur++;
        } 
        
        if(erreur === 0) {
            document.getElementById("erreur_name").innerHTML = "";
        }
    }
       
    if(input === "email"){
        var erreur = 0;
        if (email.value === "")                                   
        { 
            document.getElementById("erreur_email").innerHTML = "Please enter a valid e-mail address.";
            erreur++;
        } 
   
        if (email.value.indexOf("@", 0) < 0)                 
        { 
            document.getElementById("erreur_email").innerHTML = "Please enter a valid e-mail address.";
            erreur++;
        } 

        if (email.value.indexOf(".", 0) < 0)                 
        { 
            document.getElementById("erreur_email").innerHTML = "Please enter a valid e-mail address.";
            erreur++;
        } 
        
        if(erreur === 0) {
            document.getElementById("erreur_email").innerHTML = "";
        }
    }
    
    if(input === "phone"){
        var erreur = 0;
        if (phone.value === "")                           
        { 
            document.getElementById("erreur_phone").innerHTML = "Please enter your telephone number.";
            erreur++;
        }
        
        if (phone.value.length <= 5)                           
        { 
            document.getElementById("erreur_phone").innerHTML = "Please enter your telephone number.";
            erreur++;
        }
        
        if(erreur === 0) {
            document.getElementById("erreur_phone").innerHTML = "";
        }
    }
    
    if(input === "message"){
        var erreur = 0;
        if (message.value === "")                           
        { 
            document.getElementById("erreur_message").innerHTML = "Please enter your message.";
            erreur++;
        }
        
        if(erreur === 0) {
            document.getElementById("erreur_message").innerHTML = "";
        }
    }
    
    name = document.getElementById("erreur_name").innerHTML;
    email = document.getElementById("erreur_email").innerHTML;
    phone = document.getElementById("erreur_phone").innerHTML;
    message = document.getElementById("erreur_message").innerHTML;
    
    if(name === "" && email === "" && phone === "" && message === ""){
        document.getElementById("send_contact").style.display = "inline";
    }else{
        document.getElementById("send_contact").style.display = "none";
    }
    
}

function validateLogin(input) {              
    var email = document.forms["login-form"]["email"];    
    var password = document.forms["login-form"]["password"];
       
    if(input === "email"){
        var erreur = 0;
        if (email.value === "")                                   
        { 
            document.getElementById("erreur_email_login").innerHTML = "Please enter a valid e-mail address.";
            erreur++;
        } 
   
        if (email.value.indexOf("@", 0) < 0)                 
        { 
            document.getElementById("erreur_email_login").innerHTML = "Please enter a valid e-mail address.";
            erreur++;
        } 

        if (email.value.indexOf(".", 0) < 0)                 
        { 
            document.getElementById("erreur_email_login").innerHTML = "Please enter a valid e-mail address.";
            erreur++;
        } 
        
        if(erreur === 0) {
            document.getElementById("erreur_email_login").innerHTML = "";
        }
    }
    
    if(input === "password"){
        var erreur = 0;
        if (password.value === "")                           
        { 
            document.getElementById("erreur_password_login").innerHTML = "Please enter your password.";
            erreur++;
        }
        
        if(erreur === 0) {
            document.getElementById("erreur_password_login").innerHTML = "";
        }
    }
    
    email = document.getElementById("erreur_email_login").innerHTML;
    password = document.getElementById("erreur_password_login").innerHTML;
    
    if(email === "" && password === ""){
        document.getElementById("btn-login").style.display = "inline";
    }else{
        document.getElementById("btn-login").style.display = "none";
    }
    
}
                                
function login(){
    var xhr = getXMLHttpRequest();
    email = document.getElementById("mail").value;
    password = document.getElementById("key").value;
    data = "email=" + email + "&password=" + password;
    
    xhr.open("POST", 'login.php', true);

    //Send the proper header information along with the request
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function() { // Call a function when the state changes.
        if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
            xhrResponse = xhr.responseText;
            console.log(xhrResponse)
            
                                    if(xhrResponse === "ok"){
                                        location.reload();
                                    }else{
                                        document.getElementById("erreur_general_login").innerHTML = xhrResponse;
                                    }
        }
    }
    xhr.send(data); 
}
                