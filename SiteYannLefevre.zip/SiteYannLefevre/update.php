<?php
// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };
  try {
					$db = new PDO('mysql:host=localhost; dbname=siteweb', 'root', '');
				  }
				  catch(exception $e) {
					die('Erreur '.$e->getMessage());
				  }
                        $id = $_GET['id'];
			$text = addslashes($_POST['text']);
			if(!empty($text))
			{
                            $db->exec("UPDATE content SET text='$text' WHERE id='$id'");
			}
?>