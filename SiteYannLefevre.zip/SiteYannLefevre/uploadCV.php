<?php

// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_FILES['cv'])){
      $errors= array();
      //$file_name = $_FILES['cv']['name'];
      $file_size = $_FILES['cv']['size'];
      $file_tmp = $_FILES['cv']['tmp_name'];
      $file_type = $_FILES['cv']['type'];
      $explode = explode('.',$_FILES['cv']['name']);
      $file_ext=strtolower(end($explode));
      
      $expensions= array("pdf");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a pdf.";
      }
      
      if($file_size > 2097152) {
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true) {
         move_uploaded_file($file_tmp,"files/"."LEFEVRE_YANN_Resume.pdf");
         header('Location: index.php');
      }else{
         print_r($errors);
      }
   }

?>