<?php

// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_FILES['picture'])){
      $errors= array();
      $file_name = $_FILES['picture']['name'];
      $file_size = $_FILES['picture']['size'];
      $file_tmp = $_FILES['picture']['tmp_name'];
      $file_type = $_FILES['picture']['type'];
      $explode = explode('.',$_FILES['picture']['name']);
      $file_ext=strtolower(end($explode));
      
      $expensions= array("png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a png.";
      }
      
      if($file_size > 2097152) {
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true) {
         move_uploaded_file($file_tmp,"files/".$file_name.".png");
      }else{
         print_r($errors);
      }
   }

?>