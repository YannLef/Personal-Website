<?php

// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_POST['remove_project']) && isset($_POST['id'])){
       $id = $_POST['id'];
       
       
       $db->exec("DELETE FROM portfolio WHERE id = '$id'");
       unlink('img/portfolio/'.$id.'.png');
       header('Location: index.php');
   }

?>