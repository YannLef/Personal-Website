<?php

// Disable access of this file
  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    header('Location: index.php');
  };

   if(isset($_POST['update_work']) && isset($_POST['id']) && isset($_POST['title']) && isset($_POST['text']) && isset($_POST['icon']) && isset($_POST['date'])){
       $id = addslashes($_POST['id']);
       $title = addslashes($_POST['title']);
       $text = addslashes($_POST['text']);
       $icon = addslashes($_POST['icon']);
       $date = addslashes($_POST['date']);
       
       $db->exec("UPDATE work SET title='$title', text='$text', icon='$icon', date='$date' WHERE id='$id'");
       header('Location: index.php');
   }

?>