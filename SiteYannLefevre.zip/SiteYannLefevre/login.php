<?php

try {
    $db = new PDO('mysql:host=localhost; dbname=siteweb', 'root', '');
} catch (exception $e) {
    die('Erreur ' . $e->getMessage());
}
session_start();

if (isset($_POST['email']) && isset($_POST['password'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];
    if (!empty($email) AND ! empty($password)) {

        $stmt = $db->query("SELECT COUNT(*) AS nb_row FROM admin WHERE email='$email' AND password='$password'");
        $user = $stmt->fetch();

        if ($user['nb_row'] == 1) {
            $stmt = $db->query("SELECT * FROM admin WHERE email='$email' AND password='$password'");
            $user = $stmt->fetch();
            $_SESSION['id_admin'] = $user['id_admin'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['password'] = $user['password'];
            echo 'ok';
            //header('Location: index.php');
        } else {
            echo "Informations incorrectes !";
        }
    } else {
        echo "Tous les champs ne sont pas remplis !";
    }
}
?>